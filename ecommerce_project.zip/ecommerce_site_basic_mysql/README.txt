
# Simple E-Commerce Website (Flask + MySQL)

## Setup Instructions

1. Create a MySQL database named `ecommerce`.
2. Run the following SQL to create the `products` table:

CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    description TEXT,
    price DECIMAL(10,2)
);

3. Insert some sample data into the `products` table.

4. Update `app.py` with your MySQL credentials.

5. Run the app:
   python app.py

6. Open your browser and go to http://localhost:5000
